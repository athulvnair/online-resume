/*
This is empty on purpose! Your code to build the resume will go here.
 */
  
  
  //var name="ATHUL V NAIR";
  //var role="Front end web developer";
 // var formattedName = HTMLheaderName.replace("%data%",bio.name);
  //var formattedRole = HTMLheaderRole.replace("%data%",role);
  //$("#header").prepend(formattedName);
  //$("#header").append(formattedRole); 
  var bio = {
	"name": "ATHUL V NAIR",
	"role": "Web Developer",
	"contacts": {
		"email": "athulvnair@yahoo.com",
		"mobile": "8129046436",
		"location": "Kerala",
		"github": "athulvnair"
	},
	"welcomeMessage": "Technical aspirant willing to test my knowledge in the field to benefit the employer, myself and the society.",
	"skills": ["Coordination", "Programming","Team player"],
	"biopic": "images\\IMG_6071-1.jpg"
};
  
  var work = {
	"jobs": [{
		"employer": "Nil",
		"title": "Student",
		"location": "nil",
		"dates": "-",
		"description": "-"
	}]
};
  var education ={
	"schools": [{
			"name": "Bishop Moore Vidyapith",
			"dates": "2003-2013",
			"degree":"matriculation",
			"location": "Cherthala",
			"majors":[]
		},
		{
			"name": "St.Joseph's College of Engineering & Technology",
			"dates": "2013-2017",
			"location": "Palai",
			"degree": "B.Tech",
			"majors":["Electrical & Electronics Engineering"]
		}
	],
	"onlineCourses": [{
		"title": "Front end web development nanodegree",
		"dates": "June 2017- November 2017",
		"school": "Udacity",
		"url": "https://classroom.udacity.com/me"
	}]
};
  //$("#main").append(work.position);
  //$("#main").append(education["name"]);
var projects = {
	"projects": [{
			"title": "Scope of energy conservation at BPCL KR",
			"dates": "2017",
			"teamMembers": ["Pranav", "Bibin"],
			"images": ['https://placehold.it/300x200'],
			"description":"A comprehensive analysis on improving the energy conservation at the maintenance shop and warehouse at BPCL-KR using alternate lighting, ventilation and efficient design."
		},
		{
			"title": "Password based door lock system using 8051 microcontroller",
			"dates": "2016",
			"teamMembers": ["Ashish", "Bibin", "Athira"],
			"images": ['https://placehold.it/200x200'],
			"description": "A simple security lock system based on the 8051 microcontroller which triggers mechanical relay based on the input given by the user."
		}
	]
};
bio.display = function() {
var formattedRole = HTMLheaderRole.replace("%data%",bio.role);
  $("#header").prepend(formattedRole);
var formattedName = HTMLheaderName.replace("%data%",bio.name);
  $("#header").prepend(formattedName);
  

    $("#header").append(HTMLcontactGeneric);
  	var formattedMobile = HTMLmobile.replace("%data%",bio.contacts.mobile);
  	$("#topContacts:last, #footerContacts:last").append(formattedMobile);
  	var formattedmail = HTMLemail.replace("%data%",bio.contacts.email);
  	$("#topContacts:last, #footerContacts:last").append(formattedmail);
  	var formattedgithub = HTMLgithub.replace("%data%",bio.contacts.github);
  	$("#topContacts:last, #footerContacts:last").append(formattedgithub);
  	var formattedlocation = HTMLlocation.replace("%data%",bio.contacts.location);
  	$("#topContacts:last, #footerContacts:last").append(formattedlocation);

  
  var formattedimage = HTMLbioPic.replace("%data%",bio.biopic);
  $("#header").append(formattedimage);

  var formattedmessage = HTMLwelcomeMsg.replace("%data%",bio.welcomeMessage);
  $("#header").append(formattedmessage);
 
  $("#header").append(HTMLskillsStart);
  var formattedSkill= HTMLskills.replace("%data%",bio.skills);
  $("#skills-h3").append(formattedSkill); 

};

work.display = function() { Array.prototype.forEach.call(work.jobs, function(job) {
  $("#workExperience").append(HTMLworkStart);
  var formattedEmployer = HTMLworkEmployer.replace("%data%",job.employer);
  $(".work-entry:last").append(formattedEmployer);
  var formattedTitle = HTMLworkTitle.replace("%data%",job.title);
  $(".work-entry:last").append(formattedTitle);
  var formattedLocation = HTMLworkLocation.replace("%data%",job.location);
  $(".work-entry:last").append(formattedLocation);
   var formattedDates = HTMLworkDates.replace("%data%",job.dates);
  $(".work-entry:last").append(formattedDates);
  var formattedDescription = HTMLworkDescription.replace("%data%",job.description);
  $(".work-entry:last").append(formattedDescription);
});
}; 



education.display = function() {
	Array.prototype.forEach.call(education.schools, function(school) {
		$("#education").append(HTMLschoolStart);
		var schoolName = HTMLschoolName.replace("%data%",school.name);
		$(".education-entry:last").append(schoolName);
		var formattedDegree = HTMLschoolDegree.replace("%data%",school.degree);
		$(".education-entry:last").append(formattedDegree);
		var formattedDates = HTMLschoolDates.replace("%data%",school.dates);
		$(".education-entry:last").append(formattedDates);
		var formattedLocation = HTMLschoolLocation.replace("%data%",school.location);
		$(".education-entry:last").append(formattedLocation);
		var formattedMajor = HTMLschoolMajor.replace("%data%",school.majors);
		$(".education-entry:last").append(formattedMajor);	
			});
	var newDiv = "<div id='newDiv' class='education-entry'></div>";
	Array.prototype.forEach.call(education.onlineCourses, function(onlineCourse) {
		$("#education").append(HTMLonlineClasses);
		$('#education').append(newDiv);
		var formattedTitle = HTMLonlineTitle.replace("%data%",onlineCourse.title);
		$(".education-entry:last").append(formattedTitle);
		var formattedSchool = HTMLonlineSchool.replace("%data%",onlineCourse.school);
		$(".education-entry:last").append(formattedSchool);
		var formattedDates = HTMLonlineDates.replace("%data%",onlineCourse.dates);
		$(".education-entry:last").append(formattedDates);
		var formattedUrl = HTMLonlineURL.replace("%data%",onlineCourse.url);
		$(".education-entry:last").append(formattedUrl);
	});		

};

$(document).click(function(loc) {
  
  var x=loc.pageX;
  var y=loc.pageY;
  logClicks(x,y);
});

// function inName(name) {
//	name =name.trim().split(" ");
//	console.log(name);
//	name[1] = name[1].toUpperCase();
//	name[0] = name[0].slice(0,1).toUpperCase() + name[0].slice(1).toLowerCase();
//	return name[0] +" "+ name[1];
//}
//$("#main").append(internationalizeButton);   

projects.display = function() {
	Array.prototype.forEach.call(projects.projects, function(project) {
		$("#projects").append(HTMLprojectStart);
		var formattedTitle = HTMLprojectTitle.replace("%data%",project.title);
		$(".project-entry:last").append(formattedTitle);
		var formattedDates = HTMLprojectDates.replace("%data%",project.dates);
		$(".project-entry:last").append(formattedDates);
		var formattedDescription = HTMLprojectDescription.replace("%data%",project.description);
		$(".project-entry:last").append(formattedDescription);
	//Array.prototype.forEach.call(projects.projects, function(image) {
		var formattedImage = HTMLprojectImage.replace("%data%",project.images);
		$(".project-entry:last").append(formattedImage);
	});
	//});
};


$("#mapDiv").append(googleMap);

bio.display();
work.display();
education.display();
projects.display();
